<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$user  = $user  ?? [];
$posts = $posts ?? [];
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>My Profile</title>
<link rel="stylesheet" href="https://cdn.tailwindcss.com">
</head>
<body class="bg-gray-100">

<div class="max-w-2xl mx-auto bg-white shadow p-6 mt-10 rounded-lg">

    <h2 class="text-2xl font-bold"><?= htmlspecialchars($user['name']) ?></h2>
    <p class="text-gray-600"><?= htmlspecialchars($user['email']) ?></p>

    <hr class="my-4">

    <h3 class="text-xl font-semibold">My Posts</h3>

    <?php foreach ($posts as $post): ?>
        <div class="p-4 bg-gray-100 rounded-lg mt-3">
            <h4 class="font-bold"><?= htmlspecialchars($post['title']) ?></h4>
            <p><?= htmlspecialchars($post['content']) ?></p>

            <div class="text-sm text-gray-600 mt-2">
                ❤️ <?= $post['like_count'] ?> likes  
                💬 <?= $post['comment_count'] ?> comments
            </div>
        </div>
    <?php endforeach; ?>

</div>

</body>
</html>
