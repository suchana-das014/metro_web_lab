<?php if (session_status() === PHP_SESSION_NONE) session_start(); ?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Profile</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-10">

<div class="max-w-xl mx-auto bg-white shadow p-6 rounded-lg">

    <h2 class="text-2xl font-semibold mb-4">Edit Profile</h2>

    <form action="/update-profile" method="POST" enctype="multipart/form-data">

        <label class="font-semibold">Bio</label>
        <textarea name="bio" class="w-full border rounded p-2 mb-4" rows="4">
            <?= htmlspecialchars($user['bio'] ?? '') ?>
        </textarea>

        <label class="font-semibold">Profile Picture</label><br>
        <img src="/<?= htmlspecialchars($user['profile_picture'] ?? 'uploads/profile/default.png') ?>"
             class="w-24 h-24 rounded-full border mb-3 object-cover">

        <input type="file" name="picture" class="mb-4">

        <input type="hidden" name="old_picture"
               value="<?= htmlspecialchars($user['profile_picture']) ?>">

        <button class="bg-blue-600 text-white px-4 py-2 rounded">
            Save Changes
        </button>
    </form>

</div>

</body>
</html>
