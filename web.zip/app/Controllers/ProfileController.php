<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Models\User;
use App\Models\Post;

class ProfileController extends Controller
{
    public function index()
    {
        session_start();

        if (!isset($_SESSION['user_id'])) {
            header("Location: /login");
            exit;
        }

        $userId = $_SESSION['user_id'];
        $user = User::findById($userId);
        $posts = Post::getPostsByUser($userId);

        return $this->view('auth/profile', [
            'user'  => $user,
            'posts' => $posts
        ]);
    }
}
